﻿namespace Beasts.Data;

public class Beast
{
    public string Path;
    public string DisplayName;
    public string[] Crafts;
}
